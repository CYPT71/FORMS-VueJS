export type ContextListProps = {
  options: string[]
}

export type ContextListEmits = {
  (e: 'select', value: string): void
}

export type ContextMenu = {
  optionsStrings: string[]
}
