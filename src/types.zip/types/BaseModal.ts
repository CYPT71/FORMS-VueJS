export type BaseModal = { isOpen: boolean }
