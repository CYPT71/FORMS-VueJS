export type Profile = {
  imgLink?: string
}
