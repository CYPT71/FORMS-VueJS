export type InfoBox = {
  containerIdName?: string
}


export type InfoContainer = {
  style?: Record<string, string>
}
