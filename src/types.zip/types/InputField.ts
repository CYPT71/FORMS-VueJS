type InputField = {
  placeholder?: string,
  value?: string,
  inputType: "text" | "file" | "checkbox" | "submit",
  fileID?: string,
  label?: string
}


type InputFieldInner = InputField & {
  onChange?: (e: Event) => void
}


export type {
  InputField,
  InputFieldInner
}
