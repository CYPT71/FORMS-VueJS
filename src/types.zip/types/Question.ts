export type Question =  {
  id: string;
  label: string;
  answer?: string;
  children?: Question[];
}


export type QuestionBlock =  {
  question: Question,
  errors: errorType
}

export type QuestionInput = {
  question: Question,
  error?: string
}

export type errorType = Record<string, string>

export type QuestionEmit = {
  (e: 'update:answer', id: string, value: string): void
}
