export type BaseLayout = {
  headerText?: string
  leftText?: string
  rightText?: string
  footerText?: string
}

export type Section = {
  id?: string
  text?: string
  bg?: string
  color?: string
}


export type Column = {
  id: string
}
